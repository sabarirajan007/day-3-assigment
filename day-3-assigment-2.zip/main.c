/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <stdio.h>

int isPrime(int num);

int main() {
    int num, i, flag = 0;
    
    printf("Enter a positive integer: ");
    scanf("%d", &num);
    
    for(i = 2; i <= num/2; ++i) {
        if (isPrime(i) == 1) {
            if (isPrime(num - i) == 1) {
                printf("%d = %d + %d\n", num, i, num-i);
                flag = 1;
            }
        }
    }
    
    if (flag == 0) {
        printf("%d cannot be expressed as the sum of two prime numbers.", num);
    }
    
    return 0;
}

int isPrime(int num) {
    int i;
    
    if(num == 1 || num == 0) {
        return 0;
    }
    
    for(i = 2; i <= num/2; ++i) {
        if(num % i == 0) {
            return 0;
        }
    }
    
    return 1;
}

